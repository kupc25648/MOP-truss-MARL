import pandas as pd
'''
df = pd.read_csv("opt01.txt", sep=" ").replace('[', '').replace('[', '')
df.columns = ['Nan','step','V', 'dt']
print(df)

df.to_csv("./opt01.csv")

df = pd.read_csv("opt02.txt", sep=" ").replace('[', '').replace('[', '')
df.columns = ['Nan','step','V', 'dt']
print(df)

df.to_csv("./opt02.csv")
'''
for i in range(1,10):
    df = pd.read_csv("opt0{}.txt".format(i), sep=" ").replace('[', '').replace('[', '')
    df.columns = ['Nan','step','V', 'dt']
    print(df)

    df.to_csv("./opt0{}.csv".format(i))

df = pd.read_csv("opt10.txt", sep=" ").replace('[', '').replace('[', '')
df.columns = ['Nan','step','V', 'dt']
print(df)

df.to_csv("./opt10.csv".format(i))




