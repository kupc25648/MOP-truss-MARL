'''
=====================================================================
Master file for MOEAD benchmark for MOMARL truss structure
=====================================================================
'''

#====================================================================
#Import Part
#====================================================================
#from set_seed_global import seedThis
from FEM_2Dtruss import *
from truss2D_GEN import *

import multiprocessing
import pandas as pd
import datetime

import random
import numpy as np


from pymoo.core.problem import ElementwiseProblem
from pymoo.algorithms.moo.moead import MOEAD
from pymoo.optimize import minimize
from pymoo.problems import get_problem
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.visualization.scatter import Scatter

#====================================================================
#PARAMETERS Part
#====================================================================
#----------------------------------
# GEN parameters
#----------------------------------
gen_load_x           = 0
gen_load_y           = -8000
gen_topo_code        = None

testChoice = [[[5,5,5,5,5,5,5,5,5,5,5,5,5,5,5],
                [6.0],
                [3.00, 2.75, 2.50, 2.25, 2.25, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.25, 2.25, 2.50, 2.75, 3.00],
                6.0,0]]

truss_type='roof'
support_case=1
topo_code=None

num_x = len(testChoice[0][0])+1
num_y = len(testChoice[0][1])+1
dmin = 0.3#sum(testChoice[0][0])*0.01

dummy_model = gen_model(num_x,num_y,testChoice[0][0],testChoice[0][1],testChoice[0][2],dmin,gen_load_x,gen_load_y,truss_type,support_case,gen_topo_code)


all_v = np.zeros((len(dummy_model.model.elements)),dtype=np.float32)
for num in range(len(dummy_model.model.elements)):
    all_v[num] = dummy_model.model.elements[num].area * dummy_model.model.elements[num].length

all_dt = np.zeros((len(dummy_model.model.nodes)),dtype=np.float32)
for num in range(len(dummy_model.model.nodes)):
    if dummy_model.model.nodes[num].top_node == 1:
        all_dt[num] = abs(dummy_model.model.nodes[num].target - dummy_model.model.nodes[num].coord[1])

int_obj1 = np.sum(all_v)  # INITIself.model.nodesAL Truss volume
int_obj2 = np.sum(all_dt) # INITIAL Difference btw target geometry and current truss geometry

#----------------------------------
# NSGAII parameters
#----------------------------------
NGEN = 20 # Number of Generation
MU = 1200 # Number of individual in population
CXPB = 0.8 #Crossover probability
#1,000,000
#200,000
num_node_gene = len(dummy_model.model.nodes)
num_elem_gene = len(dummy_model.model.elements)

NDIM = num_node_gene+num_elem_gene # Number of dimension of the individual (=number of gene)

# Bounds on the first 12 genes
LOW1, UP1 = 0, 1#testChoice[0][1][0]*100

# Bounds on the last 26 genes
LOW2, UP2 = 0, 1#4

BOUNDS = [(LOW1, UP1) for i in range(NDIM-num_elem_gene)] + [(LOW2, UP2) for i in range(num_elem_gene)]


#----------------------------------
# pymoo problem class
#----------------------------------
class MyProblem(ElementwiseProblem):

    def __init__(self,model):
        super().__init__(n_var=len(BOUNDS),
                         n_obj=2,
                         xl=np.array([0 for i in range(len(BOUNDS))]),
                         xu=np.array([1 for i in range(len(BOUNDS))]))

        self.dummy_model = model
        self.num_analysis = 0

    def _evaluate(self, x, out, write=False, id_no=None, *args, **kwargs):
        eval_matice = self.dummy_model.read_genes(x, int_obj1, int_obj2)

        objective1 = eval_matice[0]
        objective2 = eval_matice[1]
        constraint1 = eval_matice[2]
        constraint2 = eval_matice[3]

        if (constraint1 > 1) or (constraint2 > 1):
            objective1, objective2 = 1, 1

        if write:
            if (constraint1 <= 1) and (constraint2 <= 1):
                name = './final_pareto/Sol_{}_obj1_{:0.3f}_obj2_{:0.3f}.txt'.format(id_no, objective1, objective2)
                self.dummy_model.savetxt(name)

        out["F"] = [objective1, objective2]

        self.num_analysis += 1


problem = MyProblem(dummy_model)


#----------------------------------
# pymoo MOEAD class
#----------------------------------
# (num_analysis = (n_neighbors+1)*iteration): 24000



num_neighbors = 1199
num_iteration = 20

ref_dirs = get_reference_directions("uniform", 2, n_partitions=num_neighbors)

algorithm = MOEAD(
    ref_dirs,
    n_neighbors=num_neighbors,
    prob_neighbor_mating=0.5,
)



for i in range(10):
    print('-------------------------')
    print('SEED {}'.format(i))
    seed = i*10
    problem.num_analysis = 0
    res = minimize(problem,
                   algorithm,
                   ('n_gen', num_iteration),
                   seed=seed,
                   verbose=False)

    #Scatter(bounds=[0,1]).add(res.F).show()
    print(problem.num_analysis)
    #print(res.F)
    # Saving the Pareto Front, for further exploitation
    with open('./pareto_seed_{}.txt'.format(int(seed)), 'w') as front:
        for ind in res.F:
            front.write('('+str(ind[0])+', '+str(ind[1])+')' + '\n')
