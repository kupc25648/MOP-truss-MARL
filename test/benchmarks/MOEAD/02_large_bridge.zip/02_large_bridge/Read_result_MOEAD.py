import pandas as pd

for i in range(10):
    seed_num = i*10
    df = pd.read_csv("pareto_seed_{}.txt".format(seed_num), sep=" ").replace('[', '').replace('[', '')
    df.columns = ['V','dt']

    print(df)
    for i in range(len(df)):
        df['V'][i] = df['V'][i][1:-1]
        df['dt'][i] = df['dt'][i][:-1]

        print(i)
    for i in range(len(df)):
        try:
            df['V'][i] = pd.to_numeric(df['V'][i], errors='coerce')
            df['V'][i] = df['V'][i].round(3)
        except:
            pass
        try:
            df['dt'][i] = pd.to_numeric(df['dt'][i], errors='coerce')
            df['dt'][i] = df['dt'][i].round(3)
        except:
            pass

    # Identify and remove rows with similar values in both columns

    df = df[~df.duplicated(subset=['V', 'dt'], keep='first')]

    print(df)
    df.to_csv("./pareto_seed_MOEAD_{}.csv".format(seed_num))


