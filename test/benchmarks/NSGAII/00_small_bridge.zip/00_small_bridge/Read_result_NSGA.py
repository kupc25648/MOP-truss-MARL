import pandas as pd

for i in range(10):
    seed_num = i*10
    df = pd.read_csv("pareto_seed_{}.txt".format(seed_num), sep=" ").replace('[', '').replace('[', '')
    df.columns = ['V','dt']

    print(df)
    for i in range(len(df)):
        df['V'][i] = df['V'][i][1:-1]
        df['dt'][i] = df['dt'][i][:-1]

        print(i)
    print(df)
    df.to_csv("./pareto_seed_NSGA_{}.csv".format(seed_num))


