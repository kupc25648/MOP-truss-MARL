seedThis = 10
