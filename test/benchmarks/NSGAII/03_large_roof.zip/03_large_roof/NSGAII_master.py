'''
=====================================================================
Master file for NSGAII benchmark for MOMARL truss structure
=====================================================================
'''

#====================================================================
#Import Part
#====================================================================
#from set_seed_global import seedThis
from FEM_2Dtruss import *
from truss2D_GEN import *

import multiprocessing
import pandas as pd
import datetime

import random
import numpy as np


from deap import base
from deap import creator
from deap import tools

#====================================================================
#PARAMETERS Part
#====================================================================
#----------------------------------
# GEN parameters
#----------------------------------
gen_load_x           = 0
gen_load_y           = -8000
gen_topo_code        = None

testChoice = [[[5,5,5,5,5,5,5,5,5,5,5,5,5,5,5],
                [6.0],
                [3.00, 2.75, 2.50, 2.25, 2.25, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.25, 2.25, 2.50, 2.75, 3.00],
                6.0,0]]

truss_type='roof'
support_case=1
topo_code=None

num_x = len(testChoice[0][0])+1
num_y = len(testChoice[0][1])+1
dmin = 0.3#sum(testChoice[0][0])*0.01

dummy_model = gen_model(num_x,num_y,testChoice[0][0],testChoice[0][1],testChoice[0][2],dmin,gen_load_x,gen_load_y,truss_type,support_case,gen_topo_code)


all_v = np.zeros((len(dummy_model.model.elements)),dtype=np.float32)
for num in range(len(dummy_model.model.elements)):
    all_v[num] = dummy_model.model.elements[num].area * dummy_model.model.elements[num].length

all_dt = np.zeros((len(dummy_model.model.nodes)),dtype=np.float32)
for num in range(len(dummy_model.model.nodes)):
    if dummy_model.model.nodes[num].top_node == 1:
        all_dt[num] = abs(dummy_model.model.nodes[num].target - dummy_model.model.nodes[num].coord[1])

int_obj1 = np.sum(all_v)  # INITIself.model.nodesAL Truss volume
int_obj2 = np.sum(all_dt) # INITIAL Difference btw target geometry and current truss geometry

#----------------------------------
# NSGAII parameters
#----------------------------------
NGEN = 20 # Number of Generation
MU = 1200 # Number of individual in population
CXPB = 0.8 #Crossover probability
#1,000,000
#200,000
num_node_gene = len(dummy_model.model.nodes)
num_elem_gene = len(dummy_model.model.elements)

NDIM = num_node_gene+num_elem_gene # Number of dimension of the individual (=number of gene)

# Bounds on the first 12 genes
LOW1, UP1 = 0, testChoice[0][1][0]*100

# Bounds on the last 26 genes
LOW2, UP2 = 0, 4

BOUNDS = [(LOW1, UP1) for i in range(NDIM-num_elem_gene)] + [(LOW2, UP2) for i in range(num_elem_gene)]

toolbox = base.Toolbox()

#----------------------------------
# NSGAII functions
#----------------------------------

def init_opti():
    creator.create("FitnessMin", base.Fitness, weights=(-1.0, -1.0 ))
    creator.create("Individual", list, typecode='d', fitness=creator.FitnessMin)

    toolbox.register("individual", init_ind, icls=creator.Individual, ranges=BOUNDS)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    toolbox.register("evaluate", evaluation)
    toolbox.register("mate", tools.cxOnePoint)
    toolbox.register("mutate", tools.mutUniformInt, low=[x[0] for x in BOUNDS],
                     up=[x[1] for x in BOUNDS], indpb=0.1 / NDIM)
    toolbox.register("select", tools.selNSGA2)

def init_ind(icls, ranges):
    genome = list()
    for p in ranges:
        genome.append(np.random.randint(*p))
    return icls(genome)

def evaluation(ind,model=dummy_model,write=False,id_no=None):

    eval_matice = dummy_model.read_genes(ind, int_obj1, int_obj2)

    objective1  = eval_matice[0]
    objective2  = eval_matice[1]
    constraint1 = eval_matice[2]
    constraint2 = eval_matice[3]

    if (constraint1 > 1) or (constraint2 > 1):
        objective1, objective2 = 1, 1
    if write:
        if (constraint1 <= 1) and (constraint2 <= 1):
            name = './final_pareto/Sol_{}_obj1_{:0.3f}_obj2_{:0.3f}.txt'.format(id_no,objective1,objective2)
            dummy_model.savetxt(name)

    return objective1 , objective2

def main():
    pareto = tools.ParetoFront()

    pop = toolbox.population(n=MU)
    graph = []
    data = []

    # Evaluate the individuals with an invalid fitness
    invalid_ind = [ind for ind in pop if not ind.fitness.valid]
    fitnesses = toolbox.map(toolbox.evaluate, invalid_ind)
    data.append(fitnesses)
    for ind, fit in zip(invalid_ind, fitnesses):
        ind.fitness.values = fit
        graph.append(ind.fitness.values)

    # This is just to assign the crowding distance to the individuals
    # no actual selection is done
    pop = toolbox.select(pop, len(pop))

    # Begin the generational process
    for gen in range(1, NGEN):
        print(gen)
        # Vary the population
        offspring = tools.selTournamentDCD(pop, len(pop))
        offspring = [toolbox.clone(ind) for ind in offspring]

        for ind1, ind2 in zip(offspring[::2], offspring[1::2]):
            if random.random() <= CXPB:
                toolbox.mate(ind1, ind2)

            toolbox.mutate(ind1)
            toolbox.mutate(ind2)
            del ind1.fitness.values, ind2.fitness.values

        # Evaluate the individuals with an invalid fitness
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        fitnesses = toolbox.map(toolbox.evaluate, invalid_ind)
        data.append(fitnesses)

        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit
            graph.append(ind.fitness.values)

        # Select the next generation population
        pop = toolbox.select(pop + offspring, MU)

    pareto.update(pop)


    return pop, pareto, graph, data

if __name__ == '__main__':

    for seed in range(10):
        seedThis = seed*10
        random.seed(seedThis)
        np.random.seed(seedThis)

        init_opti()
        # Multiprocessing pool: I want to compute faster
        #pool = multiprocessing.Pool()
        #toolbox.register("map", pool.map)
        print('------------------')
        print(seedThis)
        print('------------------')
        pop, optimal_front, graph_data, data = main()
        for i in range(len(pop)):
            _,_ = evaluation(pop[i],model=dummy_model,write=True,id_no=i)
        # Saving the Pareto Front, for further exploitation
        with open('./pareto_seed_{}.txt'.format(int(seedThis)), 'w') as front:
            for ind in optimal_front:
                front.write(str(ind.fitness) + '\n')

